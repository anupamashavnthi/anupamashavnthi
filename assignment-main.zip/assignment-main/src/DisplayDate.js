import React, { useState } from 'react'
import axios from 'axios';


function DisplayDate() {
    const [name, setName] = useState('')
    const [date, setDate] = useState('')
    let name1='';
    let day = '';
    const submitDate = ()=>{
        axios.post('http://localhost:8080/date',{"name":name,"date":date}).then(resp=>{
            name1  = resp.data.name;
            day = resp.data.day;
            const error = resp.data.message;
            if (name1 && day){
                const elem = document.getElementById("output");
                elem.innerHTML = `Hii ${name1}, You were born on ${day}.`
            }else{
                const elem = document.getElementById("output");
                elem.innerHTML = error
            }
        })
        .catch(error=>{
            console.log(error)
        })
    }
    return (
        <React.Fragment>
                <div id="output"></div>
                <div className="form">
                    <div>
                        <h4>Form</h4>
                    </div>
                    <div className="input-flex">
                        <label>Name</label>
                        <input type="text" 
                            value={name}
                            placeholder="Enter Name" 
                            onChange={e=>setName(e.target.value)}
                        ></input>
                    </div>
                    <div className="input-flex">
                        <label>date</label>
                        <input type="date" 
                            value={date}
                            placeholder="Enter Name" 
                            onChange={e=>setDate(e.target.value)}
                        ></input>
                    </div>
                    <div>
                        <button className="primary" onClick={submitDate}>submit</button>
                    </div>
                </div>
            </React.Fragment>
    )
}

export default DisplayDate
