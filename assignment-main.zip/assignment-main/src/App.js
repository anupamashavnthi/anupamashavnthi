import logo from './logo.svg';
import './App.css';
import DisplayDate from './DisplayDate'
function App() {
  return (
    <div className="App">
     <DisplayDate />
    </div>
  );
}

export default App;
